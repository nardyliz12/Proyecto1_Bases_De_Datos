import pymysql
from datetime import datetime

# Función para conectar a la base de datos
def get_db_connection():
    try:
        return pymysql.connect(
            host='autorack.proxy.rlwy.net',  # Cambia a la variable o el host correcto
            user='root',  # Cambia a la variable o el usuario correcto
            password='dHMHDevnExFbGOfGIiEburFzEHFLhyqv',  # Cambia a la variable o contraseña correctas
            db='project_BD',  # Cambia a la variable o la base de datos correcta
            port=21949  # Cambia al puerto correcto si es necesario
        )
    except pymysql.MySQLError as e:
        print(f"Error al conectar a la base de datos: {e}")
        return None
    
def save_battle_result(winner, loser):
    connection = get_db_connection()
    if connection:
        try:
            with connection.cursor() as cursor:
                cursor.execute("INSERT INTO batalla (ganador, perdedor, fecha) VALUES (%s, %s, %s)",
                                (winner, loser, datetime.now()))
                connection.commit()
        finally:
            connection.close()
        
def save_historial(usuario, result, pokemon):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    connection = get_db_connection()
    if connection:
        try:
            with connection.cursor() as cursor:
                cursor.execute("INSERT INTO Historial (fecha, usuario, resultado, pokemon_elegido) VALUES (%s, %s, %s, %s)",
                               (timestamp, usuario, result, pokemon))
                connection.commit()
        finally:
            connection.close()